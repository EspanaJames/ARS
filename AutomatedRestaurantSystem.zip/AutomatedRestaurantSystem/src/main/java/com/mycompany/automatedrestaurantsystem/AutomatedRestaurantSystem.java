/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.automatedrestaurantsystem;

/**
 *
 * @author Admin
 */
public class AutomatedRestaurantSystem {

    public static void main(String[] args) {
        Enter call = new Enter();
        call.setVisible(true);
    }
}

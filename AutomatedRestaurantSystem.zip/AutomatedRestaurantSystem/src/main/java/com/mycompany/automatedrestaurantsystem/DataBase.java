/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.automatedrestaurantsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author Admin
 */
public class DataBase {
      private static Connection connection;

  public static Connection connect() throws RuntimeException {
    if (connection != null) {
      return connection;
    }
    try {
      connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/menudb", "root", "");
    }
    catch (Exception ex) {
      throw new RuntimeException("Unable to connect to database.", ex);
    }
    return connection;
  }

  public static void close() {
    if (connection != null) {
      try {
        connection.close();
      }
      catch (Exception ex) {}
    }
  }
  public static void main(String[] args){
      Connection connection = DataBase.connect();
      try{
          PreparedStatement ps = connection.prepareStatement("select 1");
          boolean successful = ps.execute();
            System.out.println(successful);
      }catch(Exception ex){
          ex.printStackTrace();
      }
        finally{
          DataBase.close();
      }
  }
}
